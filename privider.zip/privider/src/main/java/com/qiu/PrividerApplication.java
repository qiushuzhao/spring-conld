package com.qiu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrividerApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrividerApplication.class, args);
	}
}
